﻿using UnityEngine;
using System.Collections;

public class CamRotate : MonoBehaviour {
	float RX;
	float RY;
	public float sensitivity = 500; // 얼마나 빨리 움직일건지? 

	// Use this for initialization
	void Start () { // 처음에 object가 생성될때 초기화 이런거 
	
	}
	
	// Update is called once per frame
	void Update () { // 게임 실행중 필요한 처리 작업 user의 입력 
		#if UNITY_EDITOR
		float mx = Input.GetAxis("Mouse Y"); // 마우스를 위아래로 움직이는건데 위로 + 아래로 -값 
        float my = Input.GetAxis("Mouse X");   // x값

        // 실제 x축(pitch)을 중심으로 한 움직임 (고개를 위아래로) = 실제 y값이 변함  (
        // y축(yaw) (고개를 좌우로 ) = 실제 x값이 변함
        // z축(roll)(forward vector)은 좌우로 까딱하는게 z축 회전 
        //오일러 앵글 = 3차원 공간에서 xyz축을 기준으로 얼만큼 호ㅣ전했는지 표시 

        RX += mx * sensitivity * Time.deltaTime; // deltaTime은 frame 에 
		RY += my * sensitivity * Time.deltaTime;

		RX = Mathf.Clamp(RX, -60, 60);

		transform.eulerAngles = new Vector3(-RX, RY, 0);
		#endif
	}
}
