﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Tower : MonoBehaviour {

	public static Tower Instance;
    //hp 를 표시할 슬ㄹ라이더 
    public Slider hpSlider;
	public int MAX_HP = 10;
	int hp = 0;

	public GameObject die;

	void Awake()
	{
        
		if(Instance == null)
			Instance = this;
	}

	void Start()
	{
        
		hp = MAX_HP;
	}

	public void Damage()
	{
		hp--;
        //슬라이더 hp를 세팅한다
        hpSlider.value = hp;
		if(hp <= 0)
		{
			if(die)
			{
				die.SetActive(true);
			}
		}
	}
}
